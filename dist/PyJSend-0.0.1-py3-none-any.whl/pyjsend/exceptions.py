class MissingResponseCode(Exception):
    pass
