import os.path
import os

_ROOT = os.path.abspath(os.path.dirname(__file__))


def get_data(path):
    return os.path.join(_ROOT, 'data', path)


RESPONSES_TABLE_FILE_PATH = get_data('responses_table.json')
