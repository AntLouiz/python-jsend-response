RESPONSES_TABLE_FILE_PATH = './responses_table.json'
