import os.path

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
RESPONSES_TABLE_FILE_PATH = os.path.join(BASE_DIR, "data", "responses_table.json")
